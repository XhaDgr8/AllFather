<?php $__env->startSection('page-vars'); ?>
    <?php
        $active = "products";
        $subActive = 'products_all';
        $title = 'All Products';
        $bread = ['Products' ,'active' => 'All Products'];
    ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <h1 class="text-center">Customers Management</h1>
        <p class="text-center text-primary">
            Here You can see how is assigned to which user.
        </p>
        <div class="row">
            <div class="row py-3 text-center text-small text-muted">
                <div class="col-1"><p class="m-0">cat_number</p></div>
                <div class="col-1"><p class="m-0">image</p></div>
                <div class="col-2"><p class="m-0">Name</p></div>
                <div class="col-2"><p class="m-0">Category</p></div>
                <div class="col-1"><p class="m-0">Stock Quantity</p></div>
                <div class="col-1"><p class="m-0">Price Per Unit</p></div>
                <div class="col-2"><p class="m-0">Create by</p></div>
                <div class="col"><p class="m-0">Actions</p></div>
            </div>

            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row text-muted py-2 text-center bg-white c-it border border-primary anime my-2 shadow-md hover-up rounded-lg">
                    <div class="col-1"><?php echo e($product->cat_number); ?></div>
                    <div class="col-1">
                         <?php if (isset($component)) { $__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SubProductAvatar::class, ['class' => 'shadow-sm','alt' => $product->name,'for' => $product->image,'radius' => '10%','w' => '4rem','h' => '4rem']); ?>
<?php $component->withName('sub-product-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6)): ?>
<?php $component = $__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6; ?>
<?php unset($__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>
                    <div class="col-2"><?php echo e($product->name); ?></div>
                    <div class="col-2"><?php echo e($product->category); ?></div>
                    <div class="col-1"><?php echo e($product->stock_quantity); ?></div>
                    <div class="col-1"><?php echo e($product->price_per_unit); ?></div>
                    <div class="col-2"><?php echo e($product->createdBy->profile->user_name); ?></div>
                    <div class="col-auto">
                        <a href="/product/<?php echo e($product->id); ?>" class="btn btn-link float-left text-decoration-none
                                btn-primary rounded-lg shadow-sm-primary">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'eye','class' => 'm-0 p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </a>
                    </div>
                    <div class="col-auto">
                        <a href="/product/<?php echo e($product->id); ?>/edit" class="btn btn-link float-left text-decoration-none
                         btn-primary rounded-lg shadow-sm-primary">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'edit','class' => 'm-0 p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/pages/product/index.blade.php ENDPATH**/ ?>