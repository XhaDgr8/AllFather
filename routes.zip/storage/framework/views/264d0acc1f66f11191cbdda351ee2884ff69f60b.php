<?php $__env->startSection('page-vars'); ?>
    <?php
        $active = "";$subActive = '';
        $title = "Welcome Home";
        $bread = [];
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row g-4">
        <div class="col-md-6 fadeInUp">
            <div style="height: 15rem" class="container hover-top anime cursor-pointer overflow-hidden position-relative rounded-lg shadow-md">
                <div class="position-absolute w-100 h-100 overflow-hidden" style="top: 0;left: 0">
                    <img src="<?php echo e(asset('storage/sa/mainBg.jpg')); ?>" alt="Home Background Main" class="img-fluid img-zoom w-100">
                </div>
                <div class="position-absolute hover-top anime cursor-pointer w-100 h-100 pt-5 overflow-hidden d-flex flex-column justify-content-center" style="top: 0;left: 0">
                    <h1 class="text-white mt-5 text-center font-weight-bold">
                        Welcome <?php echo e(auth()->user()->profile->user_name); ?>

                    </h1>
                    <h4 class="text-center text-white font-weight-bold">
                        You are logged in! as
                        <?php $__currentLoopData = auth()->user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userRole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p class="badge bg-primary shadow-sm-primary"><?php echo e($userRole->label); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </h4>
                </div>
            </div>
        </div>
        <div class="col-md-3 fadeInUp">
            <a href="/customer/all" style="height: 15rem" class="container text-decoration-none btn btn-link border-0
            bg-white hover-top anime cursor-pointer position-relative rounded-lg shadow-md p-2">
                <div class="container-fluid hover-top anime cursor-pointer row p-0">
                    <div class="col-auto">
                        <div style="width: 3rem;height: 3rem"
                             class="rounded-circle d-flex flex-row justify-content-center bg-warning">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'userCog','class' => 'm-0 my-auto text-white p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    </div>
                    <h1 class="font-weight-bold m-0 text-left text-dark col">
                        <?php echo e(count($customers)); ?>

                    </h1>
                    <h5 class="text-muted ml-2 mt-3 col-12">
                        Customers Gained
                    </h5>
                </div>
                <img src="<?php echo e(asset('storage/sa/customersGained.jpg')); ?>" alt="Customers" class="img-fluid hover-top anime
                cursor-pointer">
            </a>
        </div>
        <div class="col-md-3 fadeInUp">
            <div href="/customer/all" style="height: 15rem" class="container bg-white hover-top anime cursor-pointer overflow-hidden rounded-lg shadow-md p-2">
                <div class="container-fluid g-0 row p-0 hover-top anime cursor-pointer">
                    <div class="col-3 pb-0">
                        <div style="width: 3rem;height: 3rem"
                             class="rounded-circle d-flex flex-row justify-content-center alert alert-success p-0">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'userCog','class' => 'm-0 my-auto text-white p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </div>
                    </div>
                    <h1 class="font-weight-bold p-0 m-0 col">
                        <?php echo e($countWorkers); ?>

                    </h1>
                    <h5 class="text-muted ml-2 p-0 m-0 col-12">
                        Online Worker'(s)
                    </h5>
                </div>
                <div style="margin-top: -.8rem" class="w-100 d-flex flex-row hover-top anime cursor-pointer justify-content-center">
                    <img src="<?php echo e(asset('storage/sa/onlineWorker.png')); ?>" alt="Customers"
                         class="img-fluid mx-auto" style="width: 9rem;">
                </div>
            </div>
        </div>
        <div class="col-md-6 fadeInUp">
            <div class="card border-0 rounded-lg overflow-hidden shadow-md">
                <div class="card-header py-4 position-relative"
                style="background-image: url('<?php echo e(asset("storage/sa/subProducts.jpg")); ?>');
                    background-size: cover;
                    background-repeat: no-repeat;
                    background-position: top;">
                    <h1 class="text-muted display-4 m-0 font-weight-bold">
                        All Products
                    </h1>
                </div>
                <ul class="list-group list-group-flush" style="max-height: 15rem;overflow-y: scroll">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <div class="d-inline">
                                 <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => 'shadow-sm mr-2','for' => $product->image,'radius' => '100%','w' => '2.5rem','h' => '2.5rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                            <div class="d-inline"><?php echo e($product->name); ?></div>
                            <div class="d-inline float-right">
                                <a href="/product/<?php echo e($product->id); ?>" class="btn btn-link text-decoration-none
                                btn-primary rounded-lg shadow-sm-primary">
                                     <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'eye','class' => 'm-0 p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <div class="col-md-6 fadeInUp">
            <div class="card border-0 rounded-lg overflow-hidden shadow-md">
                <div class="card-header py-4 position-relative"
                style="background-image: url('<?php echo e(asset("storage/sa/subProducts.jpg")); ?>');
                    background-size: cover;
                    background-repeat: no-repeat;
                    background-position: top;">
                    <h1 class="text-muted display-4 m-0 font-weight-bold">
                        All Sub Products
                    </h1>
                </div>
                <ul class="list-group list-group-flush" style="max-height: 15rem;overflow-y: scroll">
                    <?php $__currentLoopData = $subProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <div class="d-inline">
                                 <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => 'shadow-sm mr-2','for' => $product->image,'radius' => '100%','w' => '2.5rem','h' => '2.5rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                            <div class="d-inline"><?php echo e($subProduct->name); ?></div>
                            <div class="d-inline float-right">
                                <a href="/sub-product/<?php echo e($subProduct->id); ?>" class="btn btn-link text-decoration-none
                                btn-primary rounded-lg shadow-sm-primary">
                                     <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'eye','class' => 'm-0 p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>


        <div class="col-md-6 fadeInUp">
            <div class="card border-0 rounded-lg overflow-hidden shadow-md">
                <div class="card-header py-4 position-relative"
                     style="background-image: url('<?php echo e(asset("storage/sa/subProducts.jpg")); ?>');
                         background-size: cover;
                         background-repeat: no-repeat;
                         background-position: top;">
                    <h1 class="text-muted display-4 m-0 font-weight-bold">
                        All Customers
                    </h1>
                </div>
                <ul class="list-group list-group-flush" style="max-height: 15rem;overflow-y: scroll">
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            <div class="d-inline">
                                 <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => 'shadow-sm mr-2','for' => $customer->profile->avatar,'radius' => '100%','w' => '2.5rem','h' => '2.5rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                            <div class="d-inline"><?php echo e($customer->profile->user_name); ?></div>
                            <div class="d-inline float-right">
                                <a href="/customers/<?php echo e($customer->id); ?>/edit" class="btn btn-link text-decoration-none
                                btn-primary rounded-lg shadow-sm-primary">
                                     <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'eye','class' => 'm-0 p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </a>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/home.blade.php ENDPATH**/ ?>