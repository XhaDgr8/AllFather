<?php $__env->startSection('page-vars'); ?>
    <?php
        $active = "empty";
        $subActive = '';
        $title = 'Account Settings';
        $bread = ['Pages' ,'active' => 'Profile'];
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- account setting page start -->
    <section id="page-account-settings">
        <div class="row">
            <!-- left menu section -->
            <div class="col-md-3 mb-2 mb-md-0">
                <ul class="nav nav-pills flex-column mt-md-0 mt-1">
                    <li class="nav-item">
                        <a class="nav-link d-flex py-75 text-dark active hovered" id="account-pill-general" data-toggle="pill"
                           href="#account-vertical-general" aria-expanded="true">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'circle','class' => 'mr-2 mt-1','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            General
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link d-flex text-dark hovered py-75" id="account-pill-password" data-toggle="pill"
                           href="#account-vertical-password" aria-expanded="false">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'circle','class' => 'mr-2 mt-1','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            Change Password
                        </a>
                    </li>
                </ul>
            </div>
            <!-- right content section -->
            <div class="col-md-9">
                <div class="card border-0 shadow-md rounded-lg">
                    <div class="card-content">
                        <div class="card-body">
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="account-vertical-general"
                                     aria-labelledby="account-pill-general" aria-expanded="true">
                                    <div class="row pb-2">
                                        <div class="col-auto">
                                            <a href="javascript: void(0);">
                                                <?php  $avatar = auth()->user()->profile->avatar ?>
                                                 <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => 'rounded mr-75','for' => $avatar,'radius' => '100%','w' => '3.5rem','h' => '3.5rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                            </a>
                                        </div>
                                        <div class="col px-0 pt-2">
                                            <avatar-profile :id="<?php echo e(auth()->user()->id); ?>"></avatar-profile>
                                        </div>
                                    </div>
                                    <div class="separator m-0"></div>
                                    <form method="post" action="/customers/<?php echo e(auth()->user()->profile->id); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <div class="row">
                                            <div class="col-12">
                                                <?php if($errors->any()): ?>
                                                    <p class="alert alert-danger"><?php echo e($errors->first()); ?></p>
                                                <?php endif; ?>
                                                <?php if(session()->has('customer.updated')): ?>
                                                    <div class="p-0 px-2 alert alert-success">
                                                        <?php echo e(session('customer.updated')); ?>

                                                    </div>
                                                <?php endif; ?>
                                                <p class="text-muted mt-2 m-0 text-center">Update you Profile Information</p>
                                            </div>
                                            <?php
                                                $proArray = [
                                                                ['field' => 'user_name', 'else' => 'User Name'],
                                                                ['field' => 'address', 'else' => 'Address'],
                                                                ['field' => 'company_number', 'else' => 'Company Number'],
                                                                ['field' => 'tel', 'else' => 'Tel'],
                                                                ['field' => 'vat_no', 'else' => 'Vat No']
                                                            ]
                                            ?>
                                            <?php for($i = 0; $i < count($proArray); $i++): ?>
                                                 <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => '','name' => $proArray[$i]['field'],'type' => 'text','class' => 'my-3','label' => auth()->user()->profile->pro_profile($proArray[$i]['field'], $proArray[$i]['else']),'value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                            <?php endfor; ?>
                                            <div class="col-12 mt-3 d-flex flex-sm-row flex-column justify-content-end">
                                                <button type="submit" class="btn btn-primary shadow-md-primary mr-sm-1 mb-1 mb-sm-0">Save
                                                    changes</button>
                                                <button type="reset" class="btn btn-outline-warning">Cancel</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="tab-pane fade " id="account-vertical-password" role="tabpanel"
                                     aria-labelledby="account-pill-password" aria-expanded="false">
                                    <form method="POST" action="<?php echo e(route('password.confirm')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-12">
                                                 <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'password','class' => 'my-2','type' => 'password','label' => 'Old Password','value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label for="account-new-password">New Password</label>
                                                        <input type="password" name="password" id="account-new-password" class="form-control"
                                                               placeholder="New Password" required
                                                               data-validation-required-message="The password field is required" minlength="6">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <div class="controls">
                                                        <label for="account-retype-new-password">Retype New
                                                            Password</label>
                                                        <input type="password" name="con-password" class="form-control" required
                                                               id="account-retype-new-password" data-validation-match-match="password"
                                                               placeholder="New Password"
                                                               data-validation-required-message="The Confirm password field is required" minlength="6">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                                                <button type="submit" class="btn btn-primary mr-sm-1 mb-1 mb-sm-0">Save
                                                    changes</button>
                                                <button type="reset" class="btn btn-outline-warning">Cancel</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/pages/profile/index.blade.php ENDPATH**/ ?>