<a href="login/<?php echo e($url); ?>" style="background-color: <?php echo e($bgColor); ?>" class="btn btn-link shadow-sm">
    <img src="<?php echo e(asset('storage/sa/icons/'.$icon)); ?>"
         class="img-fluid" style="width: <?php echo e($w); ?>; height: <?php echo e($h); ?>" alt="<?php echo e($alt); ?>">
</a>
<?php /**PATH D:\xampp\htdocs\bin\resources\views/components/social-logins.blade.php ENDPATH**/ ?>