<?php $__env->startSection('page-vars'); ?>
    <?php
        $active = "customers";
        $subActive = "customer_create";
        $title = 'Create New Customer';
        $bread = ['Pages' ,'active' => 'Create Customer'];
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 shadow-lg rounded-lg overflow-hidden">
                <div class="row">
                    <div class="col-md-6 d-flex flex-column justify-content-center bg-light">
                        <img src="<?php echo e(asset('storage/sa/register.jpg')); ?>" class="img-fluid" alt="">
                    </div>
                    <div class="col-md-6 bg-white py-4">
                        <div class="container">
                            <h4><?php echo e(__('Create Account')); ?></h4>
                            <p class="mb-3 alert alert-info p-2 m-0">The email should be like this 'user_name@Perfunic.company' but you can name it anything we use the email as a backend id for managing the user.</p>
                            <?php if($errors->any()): ?>
                                <p class="alert alert-danger"><?php echo e($errors->first()); ?></p>
                            <?php endif; ?>
                            <form method="POST" action="<?php echo e(route('new.customer.create')); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                 <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'user_name','type' => 'text','class' => 'my-3','label' => 'User Name','value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'email','type' => 'text','class' => 'my-3','label' => 'Email','value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'password','type' => 'text','class' => 'my-3','label' => 'Password','value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                 <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'password_confirmation','type' => 'text','class' => 'my-3','label' => 'Confirm Password','value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                <div class="form-group row mt-3 mb-0">
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-block shadow-sm-primary text-white btn-primary">
                                            <?php echo e(__('Create')); ?>

                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/pages/customers/create.blade.php ENDPATH**/ ?>