<?php $__env->startSection('page-vars'); ?>
    <?php
        $active = "sub_products";
        $subActive = 'sub_products_create';
        $title = 'Account Settings';
        $bread = ['Sub Products', 'active' => 'Creat Sub Product'];
        $fields = [
            'cat_number' => 'Cat Number',
            'name' => 'Name',
            'country_of_origin' => 'Country of Origin',
            'facility_name' => 'Facility Name',
            'buying_unit' => 'Buying Unit',
            'price_per_unit' => 'Price Per Unit',
            'production_unit' => 'Production Unit',
            'production_price' => 'Production Price',
            'quantity' => 'Quantity',
            'price_for_customer' => 'Price For Customer',
            'price_for_admin' => 'Price For Admin',
            'other_costs' => 'Other Costs',
            'category' => 'Category',
            'key_words' => 'Key Word',
            'description' => 'Description',
            ];
    ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- app ecommerce details start -->
    <div class="bg-white border-primary border shadow-md rounded-lg">
        <div class="row mb-5 mt-2">
            <div class="col-12 col-md-5 d-flex align-items-center justify-content-center mb-2 mb-md-0">
                <div class="d-flex align-items-center justify-content-center pl-2">
                     <?php if (isset($component)) { $__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SubProductAvatar::class, ['class' => 'shadow-lg py-2 rounded-lg','alt' => '','for' => '','radius' => '','w' => '100%','h' => '100%']); ?>
<?php $component->withName('sub-product-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6)): ?>
<?php $component = $__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6; ?>
<?php unset($__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
            </div>
            <div class="col-12 col-md-6 pt-3">
                <h3 class="text-primary text-decoration-underline">Create New Product</h3>
                <form action="<?php echo e(route('sub-product.store')); ?>" method="post" class="row">
                    <?php echo csrf_field(); ?>
                    <div class="col-12">
                        <?php if($errors->any()): ?>
                            <p class="alert alert-danger"><?php echo e($errors->first()); ?></p>
                        <?php endif; ?>
                        <?php if(session()->has('subProduct.create')): ?>
                            <div class="p-0 px-2 alert alert-success">
                                <?php echo e(session('subProduct.create')); ?>

                            </div>
                        <?php endif; ?>
                            <input type="hidden" name="created_by" value="<?php echo e(auth()->user()->id); ?>">
                            <input type="hidden" name="updated_by" value="">
                    </div>
                    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key == 'description'): ?>
                            <div class="col-12">
                                <div class="form-group my-3">
                                    <div class="w-100 position-relative">
                                        <label class="small" for="<?php echo e($key); ?>" style="pointer-events: none">
                                            Description
                                        </label>
                                        <textarea id="<?php echo e($key); ?>"
                                                  class="form-control border <?php $__errorArgs = [$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                  name="<?php echo e($key); ?>"></textarea>
                                        <?php $__errorArgs = [$key];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="col-6">
                                 <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => '','name' => $key,'type' => 'text','class' => 'my-2','label' => $field,'value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 mt-3">
                        <button type="submit" class="btn anime btn-primary shadow-md-primary btn-block hovered">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'plus','class' => 'mr-3','h' => '1.5rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  Create
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- app ecommerce details end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/pages/subProduct/create.blade.php ENDPATH**/ ?>