<?php $__env->startSection('page-vars'); ?>
    <?php
        $active = "customers";
        $subActive = 'customer_all';
        $title = "All Customers";
        $bread = ['Admin', 'Pages' ,'active' => 'All Customers'];
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <h1 class="text-center">Customers Management</h1>
        <p class="text-center text-primary">
            Here You can see how is assigned to which user.
        </p>
        <div class="row">
            <div class="row py-3 text-center text-small text-muted">
                <div class="col-1"><p class="m-0">avatar</p></div>
                <div class="col-1"><p class="m-0">User Name</p></div>
                <div class="col-3"><p class="m-0">User Email</p></div>
                <div class="col-1"><p class="m-0">Status</p></div>
                <div class="col-2"><p class="m-0">Assigned Worker</p></div>
                <div class="col"><p class="m-0">Actions</p></div>
            </div>

            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row text-muted text-center bg-white c-it border border-primary anime my-2 shadow-md hover-up rounded-lg">

                    <div class="col-1 py-2">
                         <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => 'shadow-sm','for' => $customer->profile->avatar,'radius' => '10%','w' => '4rem','h' => '4rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    </div>
                    <div class="col-1 py-1"><?php echo e($customer->profile->user_name); ?></div>
                    <div class="col-3 py-1"><?php echo e($customer->email); ?></div>
                    <div class="col-1 py-1">
                        <h4 class="m-0">
                            <span class="badge alert m-0 p-1 alert-<?php echo e($customer->profile->status == 'online' ? 'success' : 'warning'); ?>">
                                <?php echo e($customer->profile->status); ?>

                            </span>
                        </h4>
                    </div>
                    <div class="col-2 py-1">
                        <?php $__currentLoopData = $customer->user_worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <form type="hidden" id="<?php echo e($worker->id); ?>" class="d-none" action="<?php echo e(route('unAssign.worker.to.customer')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($customer->id); ?>" name="customer">
                                <input type="hidden" value="<?php echo e($worker->id); ?>" name="unAssign_worker">
                            </form>
                            <button onclick="event.preventDefault();document.getElementById('<?php echo e($worker->id); ?>').submit();"
                                    class="anime hover-delete btn-sm btn my-1 px-2 rounded-pill btn-primary shadow-sm-primary d-flex flex-row justify-content-around">
                                 <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => 'shadow-sm mr-2','for' => $worker->profile->avatar,'radius' => '100%','w' => '1.2rem','h' => '1.2rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                <h6 class="m-0"><?php echo e($worker->profile->user_name); ?></h6>
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="col py-1">
                        <form class="mb-1 d-flex flex-row justify-content-around"
                              action="<?php echo e(route('assign.worker.to.customer')); ?>" method="post">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" value="<?php echo e($customer->id); ?>" name="customer">

                            <select name="assign_worker" class="form-control d-block mr-2 shadow-sm">
                                <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($worker->id); ?>"><?php echo e($worker->profile->user_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-outline-primary rounded-circle shadow-sm">
                                 <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'linkIt','class' => 'm-0 p-0','h' => '.7rem','w' => '.7rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </button>
                            <a href="/customers/<?php echo e($customer->id); ?>/edit" class="btn btn-link text-decoration-none ml-2 btn-primary rounded-lg shadow-sm-primary hovered">
                                 <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'userCog','class' => 'm-0 p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </a>
                        </form>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/pages/customers/index.blade.php ENDPATH**/ ?>