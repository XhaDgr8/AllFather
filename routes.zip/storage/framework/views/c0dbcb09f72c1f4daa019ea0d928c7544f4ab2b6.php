<?php $__env->startSection('page-vars'); ?>
    <?php
        $active = "sub_products";
        $subActive = '';
        $title = 'Sub Products';
        $bread = ['Sub Products', 'active' => 'View Sub Product'];
    ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- app ecommerce details start -->
    <div class="bg-white border-primary border shadow-md rounded-lg">
        <div class="row mb-5 mt-2">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('')): ?>
                <div class="col-12">
                    <div class="container">
                        <div class="row">
                            <div class="col-auto d-flex flex-row justify-content-start">
                                <p class="mt-3 m-0 mr-2">This Product Was Created On: <span class="text-primary font-weight-bold"><?php echo e($subProduct->created_at); ?></span> BY </p>
                                <div class="d-inline m-0 mt-2">
                                    <button class="anime btn-sm btn my-1 px-2 rounded-pill btn-primary
                            shadow-sm-primary d-flex flex-row justify-content-around">
                                         <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => 'shadow-sm mr-2','for' => $subProduct->createdBy->profile->avatar,'radius' => '100%','w' => '1.2rem','h' => '1.2rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        <h6 class="m-0"><?php echo e($subProduct->createdBy->profile->user_name); ?></h6>
                                    </button>
                                </div>
                            </div>
                            <?php if($subProduct->updated_by != ''): ?>
                                <div class="col-auto d-flex flex-row justify-content-start">
                                    <p class="mt-3 m-0 mr-2">This Product Was Last Updated On: <span class="text-primary font-weight-bold"><?php echo e($subProduct->updated_at); ?></span> BY </p>
                                    <div class="d-inline m-0 mt-2">
                                        <button class="anime btn-sm btn my-1 px-2 rounded-pill btn-primary
                            shadow-sm-primary d-flex flex-row justify-content-around">
                                             <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => 'shadow-sm mr-2','for' => $subProduct->updatedBy->profile->avatar,'radius' => '100%','w' => '1.2rem','h' => '1.2rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                            <h6 class="m-0"><?php echo e($subProduct->updatedBy->profile->user_name); ?></h6>
                                        </button>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="col-12 col-md-5 d-flex align-items-center justify-content-center mb-2 mb-md-0">
                <div class="d-flex align-items-center justify-content-center pl-3">
                     <?php if (isset($component)) { $__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SubProductAvatar::class, ['class' => 'shadow-md rounded-lg','alt' => $subProduct->name,'for' => $subProduct->image,'radius' => '','w' => '100%','h' => '100%']); ?>
<?php $component->withName('sub-product-avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6)): ?>
<?php $component = $__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6; ?>
<?php unset($__componentOriginaldf93a7734be129eb12f0adaf8eedc775d0c4c4e6); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
            </div>
            <div class="col-12 col-md-6 pt-3">
                <div class="container">
                    <h3 class="text-primary text-decoration-underline font-weight-bold font-monospace"><?php echo e($subProduct->name); ?></h3>
                    <p class="text-dark small">cat number: <?php echo e($subProduct->cat_number != "" ? $subProduct->cat_number : 'Cat Number'); ?></p>
                    <div class="row pb-2 border-bottom">
                        <div class="col-auto pl-3 pr-2 border-right">
                            <h4 class="font-weight-normal m-0 text-primary">$ <?php echo e($subProduct->price_per_unit != "" ? $subProduct->price_per_unit : 'Price Per Unit'); ?></h4>
                        </div>
                        <div class="col-auto px-2">
                            <h4 class="font-weight-normal m-0 text-muted"><?php echo e($subProduct->production_unit != "" ? $subProduct->production_unit : 'Production Unit'); ?></h4>
                        </div>
                    </div>
                    <div class="pb-2 border-bottom">
                        <p class="mt-2 text-muted">
                            <?php echo e($subProduct->description != "" ? $subProduct->description : 'Description'); ?>

                        </p>
                        <p class="small font-weight-bold text-muted">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'glob','class' => 'm-0 p-0','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php echo e($subProduct->country_of_origin != "" ? $subProduct->country_of_origin : 'Country of Origin'); ?>

                        </p>
                        <p class="small font-weight-bold text-muted">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'building','class' => 'm-0 p-0','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php echo e($subProduct->facility_name != "" ? $subProduct->facility_name : 'Facility Name'); ?>

                        </p>
                    </div>
                    <div class="mt-2">
                        <?php if($subProduct->stock_quantity != ""): ?>
                            <?php if(($subProduct->stock_quantity != 0)): ?>
                                <p class="text-muted">Available - <span class="text-success"><?php echo e($subProduct->stock_quantity); ?> In Stock</span></p>
                            <?php endif; ?>
                        <?php else: ?>
                            <p class="text-muted">Stock Quantity</p>
                        <?php endif; ?>

                        <div class="row mt-2">
                            <div class="col-6">
                                <button type="button" class="btn btn-lg btn-primary shadow-md-primary">
                                     <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'dotCircle','class' => 'm-0 mb-1 p-0','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  Add To Orders
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- app ecommerce details end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/pages/subProduct/show.blade.php ENDPATH**/ ?>