
<?php $__currentLoopData = $assigner['to']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $to): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <form type="hidden" action="<?php echo e(route($assigner['route'])); ?>"
          method="post">
        <?php echo csrf_field(); ?>
        <?php if($assigner['forName'] == 'user'): ?>
            <input type="hidden" value="<?php echo e($assigner['for']->id); ?>" name="<?php echo e($assigner['forName']); ?>">
            <input type="hidden" value="<?php echo e($to->name); ?>" name="<?php echo e($assigner['toName']); ?>">
            <button <?php echo e($assigner['for']->id == 1 ? $to->name == 'admin' ? 'disabled' : '' : ''); ?>

                    class="anime hover-delete btn-sm btn my-1 px-2
                rounded-pill btn-primary shadow-sm-primary"
                <?php echo e($attributes->merge(['class' => "$class"])); ?>>
                <h6 class="m-0"><?php echo e($to->label); ?></h6>
            </button>
        <?php else: ?>
            <input type="hidden" value="<?php echo e($assigner['for']->id); ?>" name="<?php echo e($assigner['forName']); ?>">
            <input type="hidden" value="<?php echo e($to->name); ?>" name="<?php echo e($assigner['toName']); ?>">
            <button <?php echo e($assigner['for']->name == 'admin' ? 'disabled' : ''); ?>

                    class="anime hover-delete btn-sm btn my-1 px-2
                    rounded-pill btn-primary shadow-sm-primary">
                <h6 class="m-0"><?php echo e($to->label); ?></h6>
            </button>
        <?php endif; ?>
    </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\xampp\htdocs\bin\resources\views/components/assigner.blade.php ENDPATH**/ ?>