<img src="<?php echo e(\App\Helper\Helper::avatar($for)); ?>" alt="User Profile Picture"
     <?php echo e($attributes->merge(['class' => "$class"])); ?>

     class="m-0 p-0"
     style="vertical-align: middle;width: <?php echo e($w); ?>;height: <?php echo e($h); ?>;border-radius: <?php echo e($radius); ?>">
<?php /**PATH D:\xampp\htdocs\bin\resources\views/components/avatar.blade.php ENDPATH**/ ?>