
<div id="theside" class="p-0 position-fixed"
     style="
         z-index: 2;min-height: 100%;
         width:inherit;max-width:inherit;;"
>
    <div id="particles-js" class="position-absolute w-100 h-100" style="z-index: 0"></div>
</div>
<div id="theside" class="p-0 position-fixed"
     style="
         z-index: 22;min-height: 100%;
         width:inherit;max-width:inherit;
         overflow-x: hidden;
         background-image: url('<?php echo e(asset("storage/sa/sidebarBg.png")); ?>');
         background-position: bottom;background-repeat: no-repeat;background-size: contain;"
>

    <nav class="g-0 py-2 row bg-white position-relative" style="min-width: 13rem;z-index: 33">
        <div class="col-10 p-0">
            <a class="navbar-brand nav-link" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('storage/sa/logo/logo.gif')); ?>" style="max-height: 3rem"
                     alt="" class="img-fluid float-left">
                <h1 style="font-size: 1.5rem" class="float-left d-md-block d-none logo-text font-monospace font-weight-bold m-0 mt-2">Perfumic</h1>
            </a>
        </div>
        <div id="toggle-sidebar" class="col-2 pointer open p-0 d-flex flex-column justify-content-center">
             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'dotCircle','class' => 'text-primary','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        </div>
    </nav>
    <div class="mt-2">
        <div class="accordion" id="accord">
            <div class="container">
                <?php if(auth()->user()->is_role('admin')): ?>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if (isset($component)) { $__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenueItems::class, ['menu' => $menu,'subs' => $menu['sub']]); ?>
<?php $component->withName('menue-items'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25)): ?>
<?php $component = $__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25; ?>
<?php unset($__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php if(auth()->user()->is_role('worker')): ?>
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array('worker', $menu['roles'])): ?>
                                 <?php if (isset($component)) { $__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenueItems::class, ['menu' => $menu,'subs' => $menu['sub']]); ?>
<?php $component->withName('menue-items'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25)): ?>
<?php $component = $__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25; ?>
<?php unset($__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(auth()->user()->is_role('customer')): ?>
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(in_array('customer', $menu['roles'])): ?>
                                 <?php if (isset($component)) { $__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MenueItems::class, ['menu' => $menu,'subs' => $menu['sub']]); ?>
<?php $component->withName('menue-items'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25)): ?>
<?php $component = $__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25; ?>
<?php unset($__componentOriginalca72dd6cdc36e0511999e0f5d6d531ede2c91b25); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\bin\resources\views/components/sidebar.blade.php ENDPATH**/ ?>