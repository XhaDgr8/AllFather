<div <?php echo e($attributes->merge(['class' => "$class"])); ?> class="form-group">
    <fieldset class="w-100 position-relative">
        <input id="<?php echo e($name); ?>" type="<?php echo e($type); ?>"
               class="form-control border-primary border <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               name="<?php echo e($name); ?>" value="<?php echo e(old($value)); ?>"
               placeholder="auto"
               <?php echo e($attr); ?> autocomplete="<?php echo e($name); ?>" autofocus>
        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="small" for="<?php echo e($name); ?>" style="pointer-events: none">
            <?php echo e($label); ?>

        </label>
    </fieldset>
</div>

<?php /**PATH D:\xampp\htdocs\bin\resources\views/components/text-input.blade.php ENDPATH**/ ?>