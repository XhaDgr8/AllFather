<circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="3"></circle>
<?php /**PATH D:\xampp\htdocs\bin\resources\views/icons/disc.blade.php ENDPATH**/ ?>