<div class="my-2">
    <?php if(count($subs) > 0): ?>
        <button
            class="btn text-muted btn-block hovered <?php echo e($menu['active'] == $menu['id'] ? 'btn-outline-primary shadow-md-primary ' : ""); ?>"
            type="button" data-toggle="collapse"
            data-target="#<?php echo e($menu['id']); ?>" aria-expanded="false"
            aria-controls="<?php echo e($menu['id']); ?>">
            <p class="m-0 text-left">
                 <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => ''.e($menu['icon']).'','class' => 'mr-3','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <span class="sp-lg"><?php echo e($menu['name']); ?></span>
            </p>
        </button>


        <div id="<?php echo e($menu['id']); ?>" class="collapse <?php echo e($menu['active'] == $menu['id'] ? 'show' : ""); ?>"
             aria-labelledby="<?php echo e($menu['id']); ?>" data-parent="#accord">
            <div class="card-body p-0 py-1">
                <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a id="<?php echo e($sub['id']); ?>" href="<?php echo e($sub['url']); ?>"
                       class="btn btn-block btn-link text-decoration-none text-left hovered <?php echo e($sub['active'] == $sub['id'] ? 'btn-primary shadow-md-primary ' : ""); ?>">
                         <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'circle','class' => 'mr-2','h' => '.5rem','w' => '.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <span class="sp-lg"><?php echo e($sub['name']); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php else: ?>
        <a href="<?php echo e($menu['url']); ?>" id="<?php echo e($menu['id']); ?>"
           class="btn btn-link text-muted btn-block text-decoration-none hovered <?php echo e($menu['active'] == $menu['id'] ? 'btn-primary shadow-md-primary ' : ""); ?>">
            <p class="m-0 text-left <?php echo e($menu['active'] == $menu['id'] ? 'text-white' : ""); ?>">
                 <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => ''.e($menu['icon']).'','class' => 'mr-3','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <span class="sp-lg"><?php echo e($menu['name']); ?></span>
            </p>
        </a>
    <?php endif; ?>
</div>
<?php /**PATH D:\xampp\htdocs\bin\resources\views/components/menue-items.blade.php ENDPATH**/ ?>