<?php $__env->startSection('page-vars'); ?>
    <?php
        $active = "customers";
        $subActive = '';
        $title = 'Customer Account Settings';
        $bread = ['Customer' ,'active' => 'edit Profile'];
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row shadow-md bg-white py-4 rounded-lg">
            <div class="col-4 mh-100 bg-light rounded-right pt-3 position-relative">
                <div class="mb-5">
                    <h3 class="text-center alert alert-primary ">
                        <?php echo e($profile->user_name); ?>

                    </h3>
                </div>
                <div class="row mb-5">
                    <div class="col-auto">
                        <a href="javascript: void(0);">
                             <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => 'rounded mr-75','for' => $profile->avatar,'radius' => '','w' => '5rem','h' => '5rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        </a>
                    </div>
                    <div class="col px-0 pt-2">
                        <avatar-profile :id="<?php echo e($profile->id); ?>"></avatar-profile>
                        <p class="text-muted ml-75 mt-50">
                            <small>
                                Give the customer a nice looking image it can be helpfull
                            </small>
                        </p>
                    </div>
                </div>
                <div class="bg-dark p-2 mt-5">
                    <p class="text-danger">Remember Deleting The Customer Means that you Delete everything Related to this Customer</p>
                    <form action="/customer/<?php echo e($profile->user->id); ?>" class="my-3" method="POST">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-outline-danger btn-sm rounded-lg shadow-sm">
                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'trash','class' => 'm-0 p-0','h' => '.6rem','w' => '.6rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>  Delete Customer
                        </button>
                    </form>
                </div>
            </div>
            <div class="col">
                <div class="col-12">
                    <div class="row">
                        <div class="col-6">
                            <h5 class="">Assign a Role to this Customer</h5>
                            <form class="mb-1 d-flex flex-row justify-content-center"
                                  action="<?php echo e(route('assign.role.to.user')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" value="<?php echo e($profile->user->id); ?>" name="user">

                                <select name="assign_role" class="form-control d-block mr-2 shadow-sm">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->name); ?>"><?php echo e($role->label); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-outline-primary rounded-circle shadow-sm">
                                     <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'linkIt','class' => 'm-0 p-0','h' => '.7rem','w' => '.7rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </button>
                            </form>
                        </div>
                        <div class="col-6">
                            <h5 class="">Assign a Worker to this Customer</h5>
                            <form class="mb-1 d-flex flex-row justify-content-around"
                                  action="<?php echo e(route('assign.worker.to.customer')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <input type="hidden" value="<?php echo e($profile->user->id); ?>" name="customer">

                                <select name="assign_worker" class="form-control text-dark d-block mr-2 shadow-sm">
                                    <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($worker->id); ?>"><?php echo e($worker->profile->user_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <button type="submit" class="btn btn-outline-primary rounded-circle shadow-sm">
                                     <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'linkIt','class' => 'm-0 p-0','h' => '.7rem','w' => '.7rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <form method="post" action="/customers/<?php echo e($profile->user->id); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                    <div class="row">
                        <div class="col-12">
                            <?php if($errors->any()): ?>
                                <p class="alert alert-danger"><?php echo e($errors->first()); ?></p>
                            <?php endif; ?>
                            <?php if(session()->has('customer.updated')): ?>
                                <div class="p-0 px-2 alert alert-success">
                                    <?php echo e(session('customer.updated')); ?>

                                </div>
                            <?php endif; ?>
                            <p class="text-muted mt-2 m-0 text-center">Update Customers Profile Information</p>
                        </div>
                        <?php
                            $proArray = [
                                ['field' => 'user_name', 'else' => 'User Name'],
                                ['field' => 'address', 'else' => 'Address'],
                                ['field' => 'company_number', 'else' => 'Company Number'],
                                ['field' => 'tel', 'else' => 'Tel'],
                                ['field' => 'vat_no', 'else' => 'Vat No']
                            ]
                        ?>
                        <?php for($i = 0; $i < count($proArray); $i++): ?>
                             <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => '','name' => $proArray[$i]['field'],'type' => 'text','class' => 'my-3','label' => $profile->pro_profile($proArray[$i]['field'], $proArray[$i]['else']),'value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                        <?php endfor; ?>
                        <input name="status" type="hidden" value="" />
                        <div class="col-12 d-flex flex-sm-row flex-column justify-content-end">
                            <button type="submit" class="btn btn-primary shadow-md-primary mr-sm-1 mb-1 mb-sm-0">Save
                                changes</button>
                            <button type="reset" class="btn btn-outline-warning">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/pages/customers/edit.blade.php ENDPATH**/ ?>