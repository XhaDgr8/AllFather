<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 shadow-lg rounded-lg overflow-hidden">
            <div class="row">
                <div class="col-md-6 d-flex flex-column justify-content-center bg-light">
                    <img src="<?php echo e(asset('storage/sa/login.png')); ?>" class="img-fluid" alt="">
                </div>
                <div class="col-md-6 bg-white py-5">
                    <div class="container">
                        <h4><?php echo e(__('Login')); ?></h4>
                        <p class="mb-3">Welcome back, please login to your account.</p>
                        <?php if($errors->any()): ?>
                            <p class="alert alert-danger"><?php echo e($errors->first()); ?></p>
                        <?php endif; ?>
                        <?php if(isset($msg)): ?>
                            <p class="alert alert-info"><?php echo e($msg); ?></p>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group my-4">
                                <fieldset class="w-100 position-relative">
                                    <input id="email" type="email"
                                           class="form-control border <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="email" value="<?php echo e(old('email')); ?>"
                                           placeholder="auto"
                                           required autocomplete="email" autofocus>
                                    <label for="email"><?php echo e(__('E-Mail Address')); ?></label>
                                </fieldset>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group mt-4 mb-2">
                                <fieldset class="w-100 position-relative">
                                    <input id="password" type="password"
                                           class="form-control border <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="password" value="<?php echo e(old('password')); ?>"
                                           placeholder="auto"
                                           required autocomplete="password" autofocus>
                                    <label for="password"><?php echo e(__('Password')); ?></label>
                                </fieldset>

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="form-group row my-1 g-0">
                                <div class="col-md-6">
                                    <div class="form-check mt-2">
                                        <input class="form-check-input"
                                               type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                        <label class="form-check-label" for="remember">
                                            <?php echo e(__('Remember Me')); ?>

                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <?php if(Route::has('password.request')): ?>
                                        <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot Password?')); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-6">
                                    <a href="/register" type="submit" class="btn btn-sm btn-link btn-outline-primary">
                                        <?php echo e(__('Register')); ?>

                                    </a>
                                </div>
                                <div class="col-6">
                                    <button type="submit" class="btn btn-block shadow-sm-primary text-white btn-primary">
                                        <?php echo e(__('Login')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>

                        <div class="separator my-4">OR</div>

                        <div class="my-3 row g-1">
                            <div class="col-md-3 col-6">
                                 <?php if (isset($component)) { $__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SocialLogins::class, ['icon' => 'github-alt-brands.svg','url' => 'github','bgColor' => '#24282E','w' => '2rem','h' => '2rem','alt' => 'Login to Perfumers with github']); ?>
<?php $component->withName('social-logins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74)): ?>
<?php $component = $__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74; ?>
<?php unset($__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                            <div class="col-md-3 col-6">
                                 <?php if (isset($component)) { $__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SocialLogins::class, ['icon' => 'facebook-f-brands.svg','url' => 'facebook','bgColor' => '#4285F4','w' => '2rem','h' => '2rem','alt' => 'Login to Perfumers with facebook']); ?>
<?php $component->withName('social-logins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74)): ?>
<?php $component = $__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74; ?>
<?php unset($__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                            <div class="col-md-3 col-6">
                                 <?php if (isset($component)) { $__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SocialLogins::class, ['icon' => 'google-brands.svg','url' => 'google','bgColor' => '#d34836','w' => '2rem','h' => '2rem','alt' => 'Login to Perfumers with google']); ?>
<?php $component->withName('social-logins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74)): ?>
<?php $component = $__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74; ?>
<?php unset($__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                            <div class="col-md-3 col-6">
                                 <?php if (isset($component)) { $__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\SocialLogins::class, ['icon' => 'twitter-brands.svg','url' => 'google','bgColor' => '#00acee','w' => '2rem','h' => '2rem','alt' => 'Login to Perfumers with twitter']); ?>
<?php $component->withName('social-logins'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74)): ?>
<?php $component = $__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74; ?>
<?php unset($__componentOriginalaca32de5ef6be7a1ff1d263ca0383d288a9f6b74); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fullLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/auth/login.blade.php ENDPATH**/ ?>