<svg
    xmlns="http://www.w3.org/2000/svg"
    width="<?php echo e($w != "" ? $w : ''); ?>"
    height="<?php echo e($h != "" ? $h : ''); ?>"
    focusable="false" role="img"
    <?php echo e($attributes->merge(['class' => "$class"])); ?>

    <?php if ($__env->exists("icons.$i")) echo $__env->make("icons.$i", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</svg>

<?php /**PATH D:\xampp\htdocs\bin\resources\views/components/icon.blade.php ENDPATH**/ ?>