<?php $__env->startSection('page-vars'); ?>
    <?php
        $active = "ability_role";
        $subActive = '';
        $title = "Roles & Abilities management";
        $bread = ['Admin', 'Pages' ,'active' => 'Ability_Role'];
    ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <div class="row shadow-md border py-3 rounded-lg bg-white border-primary">
            <div class="col-12"><h4 class="text-center">Ability Management</h4></div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-header border-0">There Are In Total <?php echo e(count($abilities)); ?> roles available</div>

                    <div class="card-body">
                        <?php if(session()->has('ability.updated')): ?>
                            <div class="p-0 px-2 alert alert-success">
                                <?php echo e(session('ability.updated')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="row border border-primary py-2 mb-2">
                            <div class="col">Name</div>
                            <div class="col">Label</div>
                            <div class="col-4">Actions</div>
                        </div>
                        <?php $__currentLoopData = $abilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row my-2">
                                <form method="post" action="ability/<?php echo e($ability->id); ?>" class="col-10">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <div class="row">
                                        <div class="col">
                                             <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'name','type' => 'text','class' => '','label' => $ability->name,'value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        </div>
                                        <div class="col">
                                             <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'label','type' => 'text','class' => '','label' => $ability->label,'value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        </div>
                                        <div class="col-auto">
                                            <button type="submit"
                                                    class="btn btn-outline-primary btn-sm rounded-lg shadow-sm">
                                                update
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <div class="col-auto">
                                    <form action="ability/<?php echo e($ability->id); ?>" method="post">
                                        <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
                                        <button type="submit" class="btn btn-outline-danger btn-sm rounded-lg shadow-sm">
                                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'trash','class' => 'm-0 p-0','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-header border-0">Create New Abilities</div>

                    <div class="card-body pt-0">
                        <form method="post" action="<?php echo e(route('ability.store')); ?>">
                            <?php echo csrf_field(); ?>

                            <?php if(session()->has('ability.id')): ?>
                                <div class="p-0 px-2 alert alert-<?php echo e(session('ability.id')[0]); ?>">
                                    <?php echo e(session('ability.id')[1]); ?>

                                </div>
                            <?php endif; ?>
                            <div class="p-0 m-0 px-2 alert alert-info">
                                Do not add spaces in Name Field it is for backend usage
                                <br>
                                This label will be visible to you
                            </div>
                             <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'name','type' => 'text','class' => 'mb-2 mt-3','label' => 'Ability Name','value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'label','type' => 'text','class' => 'mt-3 mb-2','label' => 'Ability Label','value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <button type="submit" class="btn-outline-primary mt-3 btn btn-block shadow-sm">
                                 <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'plus','class' => 'm-0 mr-2 p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                Make Ability
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="row shadow-md border my-5 py-3 rounded-lg bg-white border-primary">
            <div class="col-12"><h4 class="text-center">Roles Management</h4></div>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-header border-0"><p class="m-0">There Are In Total <?php echo e(count($roles)); ?> roles available</p></div>

                    <div class="card-body">
                        <?php if(session()->has('role.updated')): ?>
                            <div class="p-0 px-2 alert alert-success">
                                <?php echo e(session('role.updated')); ?>

                            </div>
                        <?php endif; ?>
                        <div class="row border border-primary py-2 mb-2">
                            <div class="col">Name</div>
                            <div class="col">Label</div>
                            <div class="col-4">Actions</div>
                        </div>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row my-2">
                                <form method="post" action="role/<?php echo e($role->id); ?>" class="col-10">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <div class="row">
                                        <div class="col">
                                             <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'name','type' => 'text','class' => '','label' => $role->name,'value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        </div>
                                        <div class="col">
                                             <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'label','type' => 'text','class' => '','label' => $role->label,'value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        </div>
                                        <div class="col-auto">
                                            <button type="submit"
                                                    class="btn btn-outline-primary btn-sm rounded-lg shadow-sm">
                                                update
                                            </button>
                                        </div>
                                    </div>
                                </form>
                                <div class="col-auto">
                                    <form action="role/<?php echo e($role->id); ?>" method="post">
                                        <?php echo csrf_field(); ?> <?php echo method_field("DELETE"); ?>
                                        <button type="submit" class="btn btn-outline-danger btn-sm rounded-lg shadow-sm">
                                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'trash','class' => 'm-0 p-0','h' => '1rem','w' => '1rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-header border-0">Create New Role</div>

                    <div class="card-body pt-0">
                        <div class="p-0 m-0 mb-3 px-2 alert alert-info">
                            Do not add spaces in Name Field it is for backend usage
                            <br>
                            This label will be visible to you
                        </div>
                        <form method="post" action="<?php echo e(route('role.store')); ?>">
                            <?php echo csrf_field(); ?>

                            <?php if(session()->has('role.id')): ?>
                                <div class="p-0 px-2 alert alert-<?php echo e(session('role.id')[0]); ?>">
                                    <?php echo e(session('role.id')[1]); ?>

                                </div>
                            <?php endif; ?>

                             <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'name','type' => 'text','class' => 'my-2','label' => 'Role Name','value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                             <?php if (isset($component)) { $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\TextInput::class, ['attr' => 'required','name' => 'label','type' => 'text','class' => 'mt-3 mb-2','label' => 'Role Label','value' => '']); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990)): ?>
<?php $component = $__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990; ?>
<?php unset($__componentOriginal86e367d7a0f86dc5cb2647e3c46305d0836a1990); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            <button type="submit" class="btn-outline-primary mt-3 btn btn-block shadow-sm">
                                 <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'plus','class' => 'm-0 mr-2 p-0','h' => '1.5rem','w' => '1.5rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                Make Role
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="container shadow-md border rounded-lg border-primary bg-white my-5 py-3">
            <div class="py-4">
                <h1 class="text-center">Assign Abilities To the Roles</h1>
                <div class="alert alert-primary mx-5">
                    <h4 class="font-weight-bold">
                        Instructions For Admin
                    </h4>
                    <p>The Admin Can perform any operation in the application;</p>
                    <p>A Role that will be assigned a specific ability will be able to perform
                        those tasks that the ability allows to that particular role.</p>

                    <div class="row">
                        <div class="col-md-6">
                            <h5>There Are In Total <?php echo e(count($roles)); ?> roles available</h5>
                            <ol>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($role->label); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </div>
                        <div class="col-md-6">
                            <h5>There Are In Total <?php echo e(count($abilities)); ?> Abilities available</h5>
                            <ol>
                                <?php $__currentLoopData = $abilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($ability->label); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="container-fluid">
                    <div class="row text-center shadow-sm border text-info font-weight-bold py-3">
                        <div class="col-2">#</div>
                        <div class="col-3">Role Name</div>
                        <div class="col-4">Have The Abilities</div>
                        <div class="col-3">Assign Ability to Role</div>
                    </div>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row text-center shadow-sm border pt-2">
                            <div class="col-2"><?php echo e($role->id); ?></div>
                            <div class="col-3"><?php echo e($role->label); ?></div>
                            <div class="col-4">
                                 <?php if (isset($component)) { $__componentOriginal1a784d780652b2776b8a93122d918193486377fd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Assigner::class, ['assigner' => [
                                            'for' => $role, 'to' => $role->abilities, 'route' => 'detach.ability.from.role',
                                            'forName' => 'role', 'toName' => 'detach_ability'
                                        ],'class' => '']); ?>
<?php $component->withName('assigner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal1a784d780652b2776b8a93122d918193486377fd)): ?>
<?php $component = $__componentOriginal1a784d780652b2776b8a93122d918193486377fd; ?>
<?php unset($__componentOriginal1a784d780652b2776b8a93122d918193486377fd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                            </div>
                            <div class="col-3">
                                <form class="mb-1 d-flex flex-row justify-content-center" action="/role/assignAbility" method="post">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" value="<?php echo e($role->id); ?>" name="role">

                                    <select name="assign_ability" class="form-control d-block mr-2 shadow-sm">
                                        <?php $__currentLoopData = $abilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ability->name); ?>"><?php echo e($ability->label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit" class="btn btn-outline-primary rounded-circle shadow-sm">
                                         <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'linkIt','class' => 'm-0 p-0','h' => '.7rem','w' => '.7rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                    </button>

                                </form>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        
        <div class="container shadow-md border rounded-lg border-primary bg-white my-5 py-3">
            <div class="p-0 py-4">
                <h1 class="text-center">User Management</h1>
                <div class="row w-auto m-auto mx-2">
                    <div class="col-12 text-center shadow-sm border text-info font-weight-bold">
                        <div class="row py-3">
                            <div class="col-1">#</div>
                            <div class="col-2">User Name</div>
                            <div class="col-3">User Email</div>
                            <div class="col-3">User Role(s)</div>
                            <div class="col-3">Assign User Role</div>
                        </div>
                    </div>
                    <div class="col-12">
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row text-center shadow-sm border">

                                <div class="col-1 py-1">
                                    <?php  $avatar = $user->profile->avatar ?>
                                     <?php if (isset($component)) { $__componentOriginal97afbeded316773b27d534f6934870f350f98e09 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Avatar::class, ['class' => '','for' => $avatar,'radius' => '100%','w' => '2.5rem','h' => '2.5rem']); ?>
<?php $component->withName('avatar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09)): ?>
<?php $component = $__componentOriginal97afbeded316773b27d534f6934870f350f98e09; ?>
<?php unset($__componentOriginal97afbeded316773b27d534f6934870f350f98e09); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </div>
                                <div class="col-2 py-1"><?php echo e($user->profile->user_name); ?></div>
                                <div class="col-3 py-1"><?php echo e($user->email); ?></div>
                                <div class="col-3 py-1">
                                     <?php if (isset($component)) { $__componentOriginal1a784d780652b2776b8a93122d918193486377fd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Assigner::class, ['assigner' => [
                                            'for' => $user, 'to' => $user->roles, 'route' => 'detach.role.from.user',
                                            'forName' => 'user', 'toName' => 'detach_role'
                                        ],'class' => '']); ?>
<?php $component->withName('assigner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal1a784d780652b2776b8a93122d918193486377fd)): ?>
<?php $component = $__componentOriginal1a784d780652b2776b8a93122d918193486377fd; ?>
<?php unset($__componentOriginal1a784d780652b2776b8a93122d918193486377fd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                </div>
                                <div class="col-3 py-1">
                                    <form class="mb-1 d-flex flex-row justify-content-center"
                                          action="<?php echo e(route('assign.role.to.user')); ?>" method="post">
                                        <?php echo csrf_field(); ?>

                                        <input type="hidden" value="<?php echo e($user->id); ?>" name="user">

                                        <select name="assign_role" class="form-control d-block mr-2 shadow-sm">
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->name); ?>"><?php echo e($role->label); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <button type="submit" class="btn btn-outline-primary rounded-circle shadow-sm">
                                             <?php if (isset($component)) { $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Icon::class, ['i' => 'linkIt','class' => 'm-0 p-0','h' => '.7rem','w' => '.7rem']); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f)): ?>
<?php $component = $__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f; ?>
<?php unset($__componentOriginalf7b6b6c4bc4eccc8de0185d678bdf3c8197f591f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                                        </button>

                                    </form>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\bin\resources\views/pages/admin/index.blade.php ENDPATH**/ ?>