<img src="<?php echo e($for != "" ? asset('storage/'.$for) : asset('storage/sa/subProducts.png')); ?>" alt="<?php echo e($alt); ?>"
     <?php echo e($attributes->merge(['class' => "$class"])); ?>

     class="m-0 p-0"
     style="vertical-align: middle;width: <?php echo e($w); ?>;height: <?php echo e($h); ?>;border-radius: <?php echo e($radius); ?>">
<?php /**PATH D:\xampp\htdocs\bin\resources\views/components/sub-product-avatar.blade.php ENDPATH**/ ?>