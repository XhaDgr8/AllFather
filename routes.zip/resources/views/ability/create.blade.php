@extends('layouts.app')

@section('content')
    ability.create template
@endsection
