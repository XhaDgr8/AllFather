@extends('layouts.app')

@section('content')
    ability.show template
@endsection
