@extends('layouts.app')

@section('content')
    ability.edit template
@endsection
