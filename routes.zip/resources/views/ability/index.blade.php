@extends('layouts.app')

@section('content')
    ability.index template
@endsection
