<a href="login/{{$url}}" style="background-color: {{$bgColor}}" class="btn btn-link shadow-sm">
    <img src="{{asset('storage/sa/icons/'.$icon)}}"
         class="img-fluid" style="width: {{$w}}; height: {{$h}}" alt="{{$alt}}">
</a>
