<div class="container-fluid shadow-sm bg-white mt-3">
    <div class="container py-3">
        <h5 class="text-center m-0">All Rights Reserved By Dev29</h5>
    </div>
</div>
