@extends('layouts.app')

@section('content')
    role.show template
@endsection
