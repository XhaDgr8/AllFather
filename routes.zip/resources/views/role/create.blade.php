@extends('layouts.app')

@section('content')
    role.create template
@endsection
