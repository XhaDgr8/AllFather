@extends('layouts.app')

@section('content')
    role.index template
@endsection
