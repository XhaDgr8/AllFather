@extends('layouts.app')

@section('content')
    profile.show template
@endsection
